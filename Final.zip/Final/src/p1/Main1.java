package p1;
import java.sql.*;


public class Main1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Main1.getCon();

	}
	public static Connection getCon()
	{
		Connection conn = null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver"); //load the driver
			conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","Final","Final");
			System.out.println("ok");
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
		return conn;
	}

}
